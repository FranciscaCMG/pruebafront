package cl.usach.ms_catalogosv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCatalogosvApplicationTests {

	@Test
	void contextLoads() {
	}

}
