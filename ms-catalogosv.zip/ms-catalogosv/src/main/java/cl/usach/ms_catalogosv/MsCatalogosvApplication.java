package cl.usach.ms_catalogosv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsCatalogosvApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsCatalogosvApplication.class, args);
	}

}
